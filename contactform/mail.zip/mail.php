<?php

 if(isset($_POST['btn-send']))
 {
    $Username = $_POST['Name'];
    $Email = $_POST['Email'];
    $Subject = $_POST['Subject'];
    $Msg = $_POST['msg'];

    if(empty($Username) || empty($Email) || empty($Subject) || empty($Msg))
    {
        header('location:index.html error');
    }
    else
    {
       $to = "ntlantlalucky50@gmail.com";

       if(mail($to,$Subject,$Msg,$Email))
       {
         header("location:index.html success");
       }
    }
 }
 else 
 {
    header('location:index.html')
 }
?>